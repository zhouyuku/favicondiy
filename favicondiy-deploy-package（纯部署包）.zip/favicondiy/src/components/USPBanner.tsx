import { ShieldCheck, Zap, Download } from "lucide-react";
import { useTranslation, Trans } from "react-i18next";

export default function USPBanner() {
  const { t } = useTranslation();

  return (
    <section className="grid grid-cols-1 md:grid-cols-3 gap-6 my-16 max-w-5xl mx-auto px-4 animate-in fade-in slide-in-from-bottom-8 duration-700 delay-200">
      <div className="flex flex-col items-center text-center p-6 bg-blue-50/50 dark:bg-blue-900/10 rounded-2xl border border-blue-100 dark:border-blue-900/20 shadow-sm hover:shadow-md transition-all">
        <div className="p-3 bg-blue-100 dark:bg-blue-900/30 rounded-full mb-4 text-blue-600 dark:text-blue-400">
          <ShieldCheck className="w-6 h-6" />
        </div>
        <h3 className="font-bold mb-2 text-lg">{t('usp.privacy.title')}</h3>
        <p className="text-sm text-muted-foreground leading-relaxed">
          <Trans i18nKey="usp.privacy.desc" components={{ strong: <strong /> }} />
        </p>
      </div>
      <div className="flex flex-col items-center text-center p-6 bg-purple-50/50 dark:bg-purple-900/10 rounded-2xl border border-purple-100 dark:border-purple-900/20 shadow-sm hover:shadow-md transition-all">
        <div className="p-3 bg-purple-100 dark:bg-purple-900/30 rounded-full mb-4 text-purple-600 dark:text-purple-400">
          <Zap className="w-6 h-6" />
        </div>
        <h3 className="font-bold mb-2 text-lg">{t('usp.preview.title')}</h3>
        <p className="text-sm text-muted-foreground leading-relaxed">
          {t('usp.preview.desc')}
        </p>
      </div>
      <div className="flex flex-col items-center text-center p-6 bg-green-50/50 dark:bg-green-900/10 rounded-2xl border border-green-100 dark:border-green-900/20 shadow-sm hover:shadow-md transition-all">
        <div className="p-3 bg-green-100 dark:bg-green-900/30 rounded-full mb-4 text-green-600 dark:text-green-400">
          <Download className="w-6 h-6" />
        </div>
        <h3 className="font-bold mb-2 text-lg">{t('usp.production.title')}</h3>
        <p className="text-sm text-muted-foreground leading-relaxed">
          <Trans i18nKey="usp.production.desc" components={{ strong: <strong />, code: <code /> }} />
        </p>
      </div>
    </section>
  );
}
