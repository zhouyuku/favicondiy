import type { ImageConfig } from "@/hooks/useImageProcessor";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { HexColorPicker } from "react-colorful";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Button } from "@/components/ui/button";
import { RotateCcw } from "lucide-react";
import { useTranslation } from "react-i18next";

interface ImageEditorProps {
  config: ImageConfig;
  updateConfig: (key: keyof ImageConfig, value: any) => void;
}

export default function ImageEditor({ config, updateConfig }: ImageEditorProps) {
  const { t } = useTranslation();
  
  const reset = () => {
    updateConfig("scale", 1);
    updateConfig("borderRadius", 0);
    updateConfig("backgroundColor", "transparent");
    updateConfig("padding", 0);
  };

  return (
    <div className="space-y-6">
      
      <div className="flex items-center justify-between">
        <h3 className="font-bold text-lg">{t('image.editor.adjustments')}</h3>
        <Button variant="ghost" size="sm" onClick={reset} className="h-8 w-8 p-0 rounded-full">
            <RotateCcw className="w-4 h-4" />
        </Button>
      </div>

      <div className="space-y-4">
        {/* Scale */}
        <div className="space-y-2">
            <div className="flex justify-between">
                <Label>{t('image.editor.scale')}</Label>
                <span className="text-xs text-muted-foreground">{Math.round(config.scale * 100)}%</span>
            </div>
            <Slider 
                value={[config.scale]} 
                min={0.1} 
                max={2} 
                step={0.05}
                onValueChange={(v) => updateConfig("scale", v[0])}
            />
        </div>

        {/* Radius */}
        <div className="space-y-2">
            <div className="flex justify-between">
                <Label>{t('image.editor.radius')}</Label>
                <span className="text-xs text-muted-foreground">{config.borderRadius}%</span>
            </div>
            <Slider 
                value={[config.borderRadius]} 
                min={0} 
                max={50} 
                step={1}
                onValueChange={(v) => updateConfig("borderRadius", v[0])}
            />
        </div>

        {/* Padding */}
        <div className="space-y-2">
            <div className="flex justify-between">
                <Label>{t('image.editor.padding')}</Label>
                <span className="text-xs text-muted-foreground">{config.padding}px</span>
            </div>
            <Slider 
                value={[config.padding]} 
                min={0} 
                max={100} 
                step={1}
                onValueChange={(v) => updateConfig("padding", v[0])}
            />
        </div>

        {/* Background */}
        <div className="space-y-2">
            <Label>{t('image.editor.background')}</Label>
            <div className="flex items-center gap-2">
                <Popover>
                    <PopoverTrigger asChild>
                        <button 
                            className="w-full h-10 rounded-md border border-input ring-offset-background relative overflow-hidden"
                        >
                            {config.backgroundColor === "transparent" ? (
                                <div className="absolute inset-0 bg-[url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAAAXNSR0IArs4c6QAAAB5JREFUKFNjYCAdMBLgwf///3+Gkf///4/XQHg4AAAB2B02Y1537gAAAABJRU5ErkJggg==')] opacity-50" />
                            ) : (
                                <div className="absolute inset-0" style={{ backgroundColor: config.backgroundColor }} />
                            )}
                        </button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-3">
                        <HexColorPicker color={config.backgroundColor === "transparent" ? "#ffffff" : config.backgroundColor} onChange={(c) => updateConfig("backgroundColor", c)} />
                        <div className="mt-2 flex gap-2">
                            <Button size="sm" variant="outline" className="w-full" onClick={() => updateConfig("backgroundColor", "transparent")}>
                                {t('image.editor.transparent')}
                            </Button>
                        </div>
                    </PopoverContent>
                </Popover>
            </div>
        </div>

      </div>
    </div>
  );
}
