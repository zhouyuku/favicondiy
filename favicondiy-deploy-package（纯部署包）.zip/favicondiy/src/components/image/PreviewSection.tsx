import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useTranslation } from "react-i18next";

interface PreviewSectionProps {
  previewUrl: string;
}

export default function PreviewSection({ previewUrl }: PreviewSectionProps) {
  const { t } = useTranslation();
  
  if (!previewUrl) return null;

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
      
      {/* Context Previews */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* Browser Tab */}
        <Card className="p-4 bg-muted/50 border-white/10 overflow-hidden">
            <h4 className="text-xs font-medium text-muted-foreground mb-3">{t('image.preview.browser_tab')}</h4>
            <div className="bg-background rounded-t-lg border border-b-0 p-2 flex items-center gap-2 max-w-[240px] shadow-sm relative">
                <img src={previewUrl} className="w-4 h-4 rounded-sm" />
                <div className="text-xs truncate flex-1">My Website - Home</div>
                <div className="text-muted-foreground hover:bg-muted p-0.5 rounded cursor-pointer">×</div>
            </div>
            <div className="bg-white h-24 border w-full rounded-b-none relative">
                <div className="absolute top-2 left-2 right-2 h-2 bg-muted/20 rounded-full" />
                <div className="absolute top-6 left-2 w-1/3 h-2 bg-muted/20 rounded-full" />
            </div>
        </Card>

        {/* Mobile Home Screen */}
        <Card className="p-4 bg-muted/50 border-white/10 flex flex-col items-center justify-center relative overflow-hidden">
            <h4 className="text-xs font-medium text-muted-foreground mb-3 self-start">{t('image.preview.home_screen')}</h4>
            <div className="absolute inset-0 bg-gradient-to-br from-indigo-500/10 to-purple-500/10 opacity-50" />
            <div className="relative z-10 flex flex-col items-center gap-2">
                <div className="w-16 h-16 rounded-[14px] overflow-hidden shadow-xl ring-1 ring-black/5 bg-white">
                    <img src={previewUrl} className="w-full h-full object-cover" />
                </div>
                <span className="text-xs font-medium text-foreground/80">App Name</span>
            </div>
        </Card>

      </div>

      {/* Generated Files List & Ad Placeholder */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        {/* File List */}
        <div className="md:col-span-2 space-y-4">
            <h3 className="text-lg font-bold">{t('image.preview.files')}</h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                {[
                    { name: "favicon.ico", size: "32x32" },
                    { name: "favicon-16x16.png", size: "16x16" },
                    { name: "favicon-32x32.png", size: "32x32" },
                    { name: "apple-touch-icon.png", size: "180x180" },
                    { name: "android-192.png", size: "192x192" },
                    { name: "android-512.png", size: "512x512" },
                ].map((file) => (
                    <Card key={file.name} className="p-3 flex items-center gap-3 bg-white/40 border-white/20">
                        <div className="w-8 h-8 rounded bg-white/50 border flex items-center justify-center p-1">
                            <img src={previewUrl} className="w-full h-full object-contain" />
                        </div>
                        <div className="flex flex-col overflow-hidden">
                            <span className="text-xs font-medium truncate" title={file.name}>{file.name}</span>
                            <span className="text-[10px] text-muted-foreground">{file.size}</span>
                        </div>
                    </Card>
                ))}
            </div>
        </div>

        {/* Ad Placeholder */}
        <div className="md:col-span-1">
            <h3 className="text-lg font-bold mb-4">{t('image.preview.sponsor')}</h3>
            <Card className="h-full min-h-[200px] bg-muted/30 border-dashed border-2 border-muted flex flex-col items-center justify-center p-6 text-center text-muted-foreground">
                <span className="text-sm font-medium">{t('image.preview.ad_space')}</span>
                <span className="text-xs mt-2 opacity-50">{t('image.preview.your_ad')}</span>
            </Card>
        </div>

      </div>

    </div>
  );
}
