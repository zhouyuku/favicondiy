import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

export type FAQItem = {
  question: string;
  answer: string;
};

interface FAQSectionProps {
  items: FAQItem[];
  title?: string;
}

export function generateFAQSchema(items: FAQItem[]) {
  return {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": items.map(item => ({
      "@type": "Question",
      "name": item.question,
      "acceptedAnswer": {
        "@type": "Answer",
        "text": item.answer
      }
    }))
  };
}

export default function FAQSection({ items, title = "Frequently Asked Questions" }: FAQSectionProps) {
  return (
    <section className="w-full max-w-3xl mx-auto py-12 px-4 animate-in fade-in slide-in-from-bottom-8 duration-700 delay-300">
      <h2 className="text-2xl font-bold font-display text-center mb-8">{title}</h2>
      <Accordion type="single" collapsible className="w-full bg-white/50 dark:bg-black/50 backdrop-blur-sm rounded-xl border px-4 shadow-sm">
        {items.map((item, index) => (
          <AccordionItem key={index} value={`item-${index}`} className="border-b-black/5 dark:border-b-white/5 last:border-0">
            <AccordionTrigger className="text-left font-medium hover:text-primary transition-colors">{item.question}</AccordionTrigger>
            <AccordionContent className="text-muted-foreground leading-relaxed">
              {item.answer}
            </AccordionContent>
          </AccordionItem>
        ))}
      </Accordion>
    </section>
  );
}
