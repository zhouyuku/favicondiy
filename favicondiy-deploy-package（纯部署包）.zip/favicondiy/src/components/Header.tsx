import { Link, useLocation } from "wouter";
import { Palette, Image as ImageIcon, Github, Smile, Globe } from "lucide-react";
import { cn } from "@/lib/utils";
import { useTranslation } from "react-i18next";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export default function Header() {
  const [location] = useLocation();
  const { t, i18n } = useTranslation();
  const isZh = i18n.language === 'zh';

  const navItems = [
    { href: "/", label: t('header.nav.text'), icon: Palette },
    { href: "/image", label: t('header.nav.image'), icon: ImageIcon },
    { href: "/emoji", label: t('header.nav.emoji'), icon: Smile },
  ];

  const handleLanguageSwitch = (targetLang: 'en' | 'zh') => {
    const currentHash = window.location.hash || '#/';
    
    if (targetLang === 'zh') {
      if (isZh) return;
      // Go to ./zh/ directory with same hash
      // If we are at root, ./zh/ works.
      window.location.href = `./zh/${currentHash}`;
    } else {
      if (!isZh) return;
      // Go to parent directory with same hash
      // If we are at /zh/, ../ works.
      window.location.href = `../${currentHash}`;
    }
  };

  return (
    <header className="flex flex-col items-center justify-center text-center mb-12 animate-in slide-in-from-top-8 fade-in duration-700 relative">
      
      {/* Language Switcher - Absolute Top Right on Desktop, relative on mobile if needed */}
      <div className="absolute top-0 right-0 hidden md:block">
         <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm" className="gap-2">
              <Globe className="w-4 h-4" />
              {isZh ? '中文' : 'English'}
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onClick={() => handleLanguageSwitch('en')}>
              English
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => handleLanguageSwitch('zh')}>
              中文
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      {/* Logo Area */}
      <div className="flex items-center gap-3 mb-8 relative">
        <div className="inline-flex items-center justify-center p-2 bg-white/50 backdrop-blur-md rounded-xl shadow-lg ring-1 ring-white/50">
          <Palette className="w-6 h-6 text-primary" />
        </div>
        <h1 className="text-3xl font-bold font-display tracking-tight text-foreground">
          Favicon<span className="text-primary">DIY</span>
        </h1>
        
        {/* Mobile Language Switcher */}
        <div className="md:hidden absolute -right-12 top-1">
             <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="h-8 w-8">
                  <Globe className="w-4 h-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => handleLanguageSwitch('en')}>
                  English
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => handleLanguageSwitch('zh')}>
                  中文
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
        </div>
      </div>

      {/* Navigation Pills */}
      <nav className="flex items-center p-1 bg-muted/50 backdrop-blur-md rounded-full ring-1 ring-white/20 shadow-sm overflow-x-auto max-w-full">
        {navItems.map((item) => {
          const isActive = location === item.href;
          return (
            <Link key={item.href} href={item.href}>
              <a
                className={cn(
                  "flex items-center gap-2 px-6 py-2.5 rounded-full text-sm font-medium transition-all duration-300 whitespace-nowrap",
                  isActive
                    ? "bg-white text-primary shadow-md ring-1 ring-black/5"
                    : "text-muted-foreground hover:text-foreground hover:bg-white/30"
                )}
              >
                <item.icon className="w-4 h-4" />
                {item.label}
              </a>
            </Link>
          );
        })}
      </nav>

    </header>
  );
}
