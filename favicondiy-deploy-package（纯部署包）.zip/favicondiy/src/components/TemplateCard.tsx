import { useState } from 'react';
import type { IconTemplate } from '@/lib/icon-templates';
import { generateAndDownloadZip } from '@/lib/exporter';
import { Card } from '@/components/ui/card';
import { Loader2, Download } from 'lucide-react';
import { toast } from 'sonner';
import { motion } from 'framer-motion';
import { useTranslation } from 'react-i18next';

interface TemplateCardProps {
  template: IconTemplate;
  text: string;
  fontFamily?: string;
  fontWeight?: string | number;
}

export default function TemplateCard({ template, text, fontFamily, fontWeight }: TemplateCardProps) {
  const [loading, setLoading] = useState(false);
  const { t } = useTranslation();

  const handleDownload = async () => {
    if (loading) return;
    setLoading(true);
    toast.loading(t('common.downloading'), { id: "download-toast" });
    
    try {
      await generateAndDownloadZip(template, text, fontFamily, fontWeight);
      toast.success(t('common.success'), { id: "download-toast" });
    } catch (e) {
      console.error(e);
      toast.error(t('common.error'), { id: "download-toast" });
    } finally {
      setLoading(false);
    }
  };

  return (
    <motion.div
      whileHover={{ scale: 1.05 }}
      className="cursor-pointer"
      onClick={handleDownload}
    >
      <Card className="relative group overflow-hidden border-0 bg-white/50 dark:bg-black/20 backdrop-blur-sm shadow-sm hover:shadow-xl transition-all duration-300 rounded-2xl aspect-square flex flex-col items-center justify-center p-6">
        
        {/* Render Template */}
        <div className="relative w-32 h-32 drop-shadow-2xl">
           <template.Component text={text} size={128} fontFamily={fontFamily} fontWeight={fontWeight} />
        </div>

        {/* Hover Overlay */}
        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center backdrop-blur-[2px]">
            {loading ? (
                <Loader2 className="w-8 h-8 text-white animate-spin" />
            ) : (
                <div className="bg-white text-black px-4 py-2 rounded-full font-bold flex items-center gap-2 transform translate-y-4 group-hover:translate-y-0 transition-transform">
                    <Download className="w-4 h-4" /> {t('common.download')}
                </div>
            )}
        </div>

        {/* Label */}
        <div className="absolute bottom-3 text-xs font-medium text-muted-foreground opacity-50 group-hover:opacity-0 transition-opacity">
            {template.name}
        </div>

      </Card>
    </motion.div>
  );
}
