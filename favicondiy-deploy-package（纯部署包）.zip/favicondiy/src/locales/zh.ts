export default {
  header: {
    nav: {
      text: "文字转 Favicon",
      image: "图片转 Favicon",
      emoji: "Emoji 转 Favicon"
    }
  },
  home: {
    hero: {
      subtitle: "输入一个字母，选择一种风格，立刻下载完整的 Favicon 图标包。即时生成，免费且隐私优先。",
      placeholder: "A",
      helper: "试着输入您的品牌首字母",
      randomize: "随机字体"
    },
    seo: {
      title: "文字转 Favicon 生成器 (2026) - 在线制作字母图标 | FaviconDIY",
      description: "即时生成专业的字母 Favicon 图标。30+ 种风格可选，自定义字体和颜色，免费下载 ICO/PNG 完整包。隐私优先，无上传。"
    },
    faq: {
      title: "文字转 Favicon 常见问题",
      q1: "2026 年最佳的 favicon 尺寸是什么？",
      a1: "对于 2026 年的现代 Web 开发，您需要混合多种尺寸：32x32 (favicon.ico) 用于旧版浏览器，16x16/32x32 PNG 用于现代桌面标签页，180x180 PNG 用于 Apple Touch Icon (iOS 主屏幕)，以及 192x192/512x512 PNG 用于 Android/PWA 清单。FaviconDIY 会自动生成所有这些尺寸。",
      q2: "如何通过文字或首字母创建 favicon？",
      a2: "只需在上方的输入框中输入您的品牌首字母或短文本（1-2 个字符）。我们的工具会立即在 30 多种专业模板中渲染它。您可以随机切换字体以找到完美匹配，然后点击任何样式进行下载。",
      q3: "这个 favicon 生成器是免费且私密的吗？",
      a3: "是的！FaviconDIY 是 100% 免费且开源的。关键在于，它使用“客户端生成”技术，这意味着您的数据和图像完全在您的浏览器内存中处理，从未上传到我们的服务器。",
      q4: "我需要手动将 PNG 转换为 ICO 吗？",
      a4: "不需要。当您从 FaviconDIY 下载包时，我们会自动生成有效的 `favicon.ico` 文件以及高质量的 PNG，因此您不需要任何外部转换工具。"
    },
    howto: {
      title: "只需 3 步制作文字 Favicon",
      s1: "输入文本",
      t1: "在主输入框中输入您的品牌首字母（1-2 个字符）。",
      s2: "选择风格",
      t2: "浏览包含渐变、霓虹和极简风格在内的 30 多种预设计模板网格。",
      s3: "下载",
      t3: "点击您喜欢的样式，即刻下载包含所有必要 favicon 格式（ICO, PNG, Manifest）的 ZIP 文件。"
    }
  },
  image: {
    hero: {
      title: "上传图片",
      subtitle: "拖放或点击上传您的 Logo (PNG, JPG, SVG)。\n推荐使用高分辨率图片 (512x512+)。",
      upload_btn: "上传其他图片",
      download_btn: "下载图标包"
    },
    editor: {
      adjustments: "调整",
      scale: "缩放",
      radius: "圆角",
      padding: "边距",
      background: "背景色",
      transparent: "透明"
    },
    preview: {
      title: "实时预览",
      browser_tab: "浏览器标签",
      home_screen: "主屏幕图标",
      files: "包含的文件",
      sponsor: "赞助商",
      ad_space: "广告位",
      your_ad: "您的广告"
    },
    seo: {
      title: "图片转 Favicon 转换器 (2026) - PNG/JPG 转 ICO | FaviconDIY",
      description: "将任何图片 (PNG, JPG, SVG) 转换为专业的 favicon 图标包。支持智能缩放、裁剪和即时预览。无需上传 - 100% 客户端处理。"
    },
    faq: {
      title: "图片转 Favicon 常见问题",
      q1: "上传我的 Logo 安全吗？它存储在哪里？",
      a1: "它是 100% 安全的。FaviconDIY 使用客户端技术，这意味着您的 Logo 图片完全在您的浏览器内存中处理。它从未上传到我们的服务器或任何云存储。您的数据保留在您的设备上。",
      q2: "支持哪些图片格式？",
      a2: "我们支持所有主流网络图片格式，包括 PNG, JPG/JPEG, SVG 和 WEBP。为了获得最佳效果，我们建议使用背景透明的高分辨率 PNG。",
      q3: "如何让我的 favicon 背景透明？",
      a3: "如果您上传带有透明度的 PNG，我们的工具默认会保留它。您也可以使用编辑器中的“背景色”选择器设置特定颜色或确保其保持透明。",
      q4: "下载中包含哪些文件？",
      a4: "ZIP 包包含 `favicon.ico` (32x32), `favicon-16x16.png`, `favicon-32x32.png`, `apple-touch-icon.png` (180x180), `android-chrome-192x192.png`, `android-chrome-512x512.png` 以及 `site.webmanifest` 文件。"
    },
    howto: {
      title: "如何将图片转换为 Favicon",
      s1: "上传图片",
      t1: "点击上传区域选择您的 Logo 文件（PNG, JPG 或 SVG）。",
      s2: "调整与预览",
      t2: "使用编辑器缩放、裁剪或为图标添加圆角，同时查看实时预览。",
      s3: "下载图标包",
      t3: "点击“下载图标包”即刻获取优化后的 favicon 文件。"
    }
  },
  emoji: {
    hero: {
      change: "更换",
      helper: "选择一个 Emoji 查看所有风格效果"
    },
    seo: {
      title: "Emoji 转 Favicon 生成器 (2026) - Emoji 转 ICO | FaviconDIY",
      description: "几秒钟内将任何 Emoji 变成自定义 favicon。浏览 1000+ Emoji，应用时尚背景，免费下载 ICO/PNG 包。隐私优先。"
    },
    faq: {
      title: "Emoji 转 Favicon 常见问题",
      q1: "我可以合法地使用 Emoji 作为 favicon 吗？",
      a1: "通常是可以的。Emoji 是 Unicode 标准的一部分。但是，特定的艺术渲染（如 Apple 或 Google 的风格）可能有版权。FaviconDIY 使用系统原生或开源兼容的 emoji 渲染进行生成。",
      q2: "如何将 Emoji 转换为 ICO？",
      a2: "很简单：从我们的选择器中选择您想要的 emoji，选择一种背景风格（如透明、渐变或纯色），然后点击下载。我们会自动将其打包为标准的 `favicon.ico` 和 PNG 组。",
      q3: "为什么我的 emoji 在不同设备上看起来不同？",
      a3: "Emoji 是由操作系统的字体渲染的。为了确保您的 favicon 对每个用户看起来都一样，FaviconDIY 将 emoji 转换为静态 PNG/ICO 图像，保留生成时您选择的外观。",
      q4: "支持最新的 2026 年 Emoji 吗？",
      a4: "是的，我们的选择器定期更新以支持最新的 Unicode emoji 标准，因此您可以使用最新的表情作为网站图标。"
    },
    howto: {
      title: "如何将 Emoji 变成 Favicon",
      s1: "挑选 Emoji",
      t1: "点击巨大的 Emoji 按钮打开选择器并选择您喜欢的表情。",
      s2: "选择背景",
      t2: "浏览模板网格，查看您的 Emoji 在不同背景（透明、霓虹、渐变）下的效果。",
      s3: "下载",
      t3: "点击您喜欢的样式，下载完整的 Favicon ZIP 包。"
    }
  },
  usp: {
    privacy: {
      title: "隐私优先",
      desc: "客户端生成技术。您的图片和文本数据**从未离开您的浏览器**。设计上安全且私密。"
    },
    preview: {
      title: "即时预览",
      desc: "在 30 多种专业设计的风格中实时渲染。即时在浏览器标签和移动屏幕上可视化您的品牌形象。"
    },
    production: {
      title: "生产就绪",
      desc: "一键下载包含 **ICO, PNG (16-512px), Apple Touch Icon** 和即用型 `site.webmanifest` 的完整包。"
    }
  },
  common: {
    download: "下载",
    downloading: "正在生成...",
    success: "下载成功！",
    error: "生成失败",
    footer: {
      copyright: "© 2026 FaviconDIY",
      privacy: "隐私",
      opensource: "开源"
    }
  }
};
