export default {
  header: {
    nav: {
      text: "Text to Favicon",
      image: "Image to Favicon",
      emoji: "Emoji to Favicon"
    }
  },
  home: {
    hero: {
      subtitle: "Type a letter, pick a style, download your complete favicon package. Instant, free, and privacy-first.",
      placeholder: "A",
      helper: "Try typing your brand initial",
      randomize: "Randomize Fonts"
    },
    seo: {
      title: "Text to Favicon Generator (2026) - Create Letter Avatars | FaviconDIY",
      description: "Generate professional letter-based favicons instantly. Choose from 30+ styles, customize fonts and colors, and download ICO/PNG packages for free. Privacy-first & no uploads."
    },
    faq: {
      title: "Text to Favicon FAQs",
      q1: "What is the best favicon size for 2026?",
      a1: "For modern web development in 2026, you need a mix of sizes: 32x32 (favicon.ico) for legacy browsers, 16x16/32x32 PNGs for modern desktop tabs, 180x180 PNG for Apple Touch Icon (iOS home screen), and 192x192/512x512 PNGs for Android/PWA manifests. FaviconDIY generates all these automatically.",
      q2: "How do I create a favicon from text or initials?",
      a2: "Simply type your brand's initial or a short text (1-2 characters) into the input box above. Our tool instantly renders it across 30+ professional templates. You can shuffle fonts to find the perfect match, then click any style to download.",
      q3: "Is this favicon generator free and private?",
      a3: "Yes! FaviconDIY is 100% free and open source. Crucially, it uses 'Client-side Generation' technology, meaning your data and images are processed entirely within your browser and are never uploaded to our servers.",
      q4: "Do I need to convert PNG to ICO manually?",
      a4: "No. When you download a package from FaviconDIY, we automatically generate a valid `favicon.ico` file along with high-quality PNGs, so you don't need any external conversion tools."
    },
    howto: {
      title: "How to Create a Text Favicon in 3 Steps",
      s1: "Enter Text",
      t1: "Type your brand initials (1-2 characters) into the main input field.",
      s2: "Select Style",
      t2: "Browse the grid of 30+ pre-designed templates including gradients, neon, and minimal styles.",
      s3: "Download",
      t3: "Click on your preferred style to instantly download a ZIP file containing all necessary favicon formats (ICO, PNG, Manifest)."
    }
  },
  image: {
    hero: {
      title: "Upload Image",
      subtitle: "Drag & drop or click to upload your logo (PNG, JPG, SVG).\nWe recommend high-res images (512x512+).",
      upload_btn: "Upload Different Image",
      download_btn: "Download Package"
    },
    editor: {
      adjustments: "Adjustments",
      scale: "Scale",
      radius: "Corner Radius",
      padding: "Padding",
      background: "Background",
      transparent: "Transparent"
    },
    preview: {
      title: "Live Previews",
      browser_tab: "Browser Tab",
      home_screen: "Home Screen",
      files: "Included Files",
      sponsor: "Sponsor",
      ad_space: "Ad Space",
      your_ad: "Your ad here"
    },
    seo: {
      title: "Image to Favicon Converter (2026) - PNG/JPG to ICO | FaviconDIY",
      description: "Convert any image (PNG, JPG, SVG) into a professional favicon package. Features smart resizing, cropping, and instant preview. No uploads required - 100% Client-side."
    },
    faq: {
      title: "Image to Favicon FAQs",
      q1: "Is it safe to upload my logo? Where is it stored?",
      a1: "It is 100% safe. FaviconDIY uses client-side technology, meaning your logo image is processed entirely within your browser's memory. It is NEVER uploaded to our servers or any cloud storage. Your data stays on your device.",
      q2: "What image formats are supported?",
      a2: "We support all major web image formats including PNG, JPG/JPEG, SVG, and WEBP. For best results, we recommend using a high-resolution PNG with a transparent background.",
      q3: "How do I make my favicon background transparent?",
      a3: "If you upload a PNG with transparency, our tool preserves it by default. You can also use the 'Background' color picker in the editor to set a specific color or ensure it remains transparent.",
      q4: "What files are included in the download?",
      a4: "The ZIP package includes `favicon.ico` (32x32), `favicon-16x16.png`, `favicon-32x32.png`, `apple-touch-icon.png` (180x180), `android-chrome-192x192.png`, `android-chrome-512x512.png`, and a `site.webmanifest` file."
    },
    howto: {
      title: "How to Convert Image to Favicon",
      s1: "Upload Image",
      t1: "Click the upload area to select your logo file (PNG, JPG, or SVG).",
      s2: "Adjust & Preview",
      t2: "Use the editor to scale, crop, or add rounded corners to your icon while watching the real-time preview.",
      s3: "Download Package",
      t3: "Click 'Download Package' to get your optimized favicon files instantly."
    }
  },
  emoji: {
    hero: {
      change: "Change",
      helper: "Pick an emoji to see it across all styles"
    },
    seo: {
      title: "Emoji to Favicon Generator (2026) - Convert Emoji to ICO | FaviconDIY",
      description: "Turn any Emoji into a custom favicon in seconds. Browse 1000+ emojis, apply stylish backgrounds, and download ICO/PNG packs for free. Privacy-first."
    },
    faq: {
      title: "Emoji to Favicon FAQs",
      q1: "Can I use Emojis as favicons legally?",
      a1: "Generally, yes. Emojis are part of the Unicode standard. However, the specific artistic rendering (like Apple's or Google's style) may have copyright. FaviconDIY uses system-native or open-source compatible emoji renderings for generation.",
      q2: "How to convert an Emoji to ICO?",
      a2: "It's simple: Select your desired emoji from our picker, choose a background style (like clear, gradient, or solid), and click to download. We automatically package it as a standard `favicon.ico` and PNG set.",
      q3: "Why does my emoji look different on different devices?",
      a3: "Emojis are rendered by the operating system's font. To ensure your favicon looks exactly the same for every user, FaviconDIY converts the emoji into a static PNG/ICO image, preserving the look you chose at the time of generation.",
      q4: "Does this support the latest 2026 emojis?",
      a4: "Yes, our picker is updated regularly to support the latest Unicode emoji standards, so you can use the newest expressions for your website icon."
    },
    howto: {
      title: "How to Turn an Emoji into a Favicon",
      s1: "Pick Emoji",
      t1: "Click the big emoji button to open the picker and select your favorite emoji.",
      s2: "Choose Background",
      t2: "Browse the template grid to see your emoji on different backgrounds (transparent, neon, gradient).",
      s3: "Download",
      t3: "Click on the style you like to download the complete favicon ZIP package."
    }
  },
  usp: {
    privacy: {
      title: "Privacy First",
      desc: "Client-side generation technology. Your images and text data **never leave your browser**. Secure and private by design."
    },
    preview: {
      title: "Instant Preview",
      desc: "Real-time rendering across 30+ professionally designed styles. Visualize your brand identity on browser tabs and mobile screens instantly."
    },
    production: {
      title: "Production Ready",
      desc: "One-click download of a complete package containing **ICO, PNG (16-512px), Apple Touch Icon**, and a ready-to-use `site.webmanifest`."
    }
  },
  common: {
    download: "Download",
    downloading: "Generating package...",
    success: "Downloaded successfully!",
    error: "Failed to generate",
    footer: {
      copyright: "© 2026 FaviconDIY",
      privacy: "Privacy",
      opensource: "Open Source"
    }
  }
};
