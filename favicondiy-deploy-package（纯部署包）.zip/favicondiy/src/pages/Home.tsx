import { useState, useEffect } from 'react';
import { TEMPLATES, FONT_CONFIGS, type FontConfig } from '@/lib/icon-templates';
import TemplateCard from '@/components/TemplateCard';
import Header from '@/components/Header';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Github, Sparkles, Shuffle } from 'lucide-react';
import bgImage from '@/assets/bg.jpg';
import SEO from '@/components/SEO';
import FAQSection, { generateFAQSchema, type FAQItem } from '@/components/FAQSection';
import USPBanner from '@/components/USPBanner';
import { useTranslation } from 'react-i18next';

export default function Home() {
  const { t } = useTranslation();
  const [text, setText] = useState("D");
  const [category, setCategory] = useState("all");
  const [fontMap, setFontMap] = useState<Record<string, FontConfig>>({});

  const FAQS: FAQItem[] = [
    { question: t('home.faq.q1'), answer: t('home.faq.a1') },
    { question: t('home.faq.q2'), answer: t('home.faq.a2') },
    { question: t('home.faq.q3'), answer: t('home.faq.a3') },
    { question: t('home.faq.q4'), answer: t('home.faq.a4') }
  ];

  const HOW_TO_SCHEMA = {
    "@context": "https://schema.org",
    "@type": "HowTo",
    "name": t('home.howto.title'),
    "step": [
      { "@type": "HowToStep", "name": t('home.howto.s1'), "text": t('home.howto.t1') },
      { "@type": "HowToStep", "name": t('home.howto.s2'), "text": t('home.howto.t2') },
      { "@type": "HowToStep", "name": t('home.howto.s3'), "text": t('home.howto.t3') }
    ]
  };

  const filteredTemplates = category === "all" 
    ? TEMPLATES 
    : TEMPLATES.filter(t => t.category === category);

  const categories = ["all", ...Array.from(new Set(TEMPLATES.map(t => t.category)))];

  const shuffleFonts = () => {
    const newMap: Record<string, FontConfig> = {};
    TEMPLATES.forEach(t => {
       const randomConfig = FONT_CONFIGS[Math.floor(Math.random() * FONT_CONFIGS.length)];
       newMap[t.id] = randomConfig;
    });
    setFontMap(newMap);
  };

  useEffect(() => {
    shuffleFonts();
  }, []);

  return (
    <div className="min-h-screen bg-background relative font-sans selection:bg-primary/20">
      
      <SEO 
        title={t('home.seo.title')}
        description={t('home.seo.description')}
        canonical="/"
        structuredData={[generateFAQSchema(FAQS), HOW_TO_SCHEMA]}
      />

      <div className="fixed inset-0 pointer-events-none z-0 opacity-30">
        <div className="absolute top-0 left-0 w-full h-full bg-cover bg-center" style={{ backgroundImage: `url(${bgImage})` }} />
        <div className="absolute inset-0 bg-white/60 dark:bg-black/60 backdrop-blur-3xl" />
      </div>

      <div className="relative z-10 container mx-auto px-4 py-12 max-w-6xl">
        
        <Header />

        <main>
            {/* Hero */}
            <div className="text-center mb-12 max-w-2xl mx-auto">
                <p className="text-lg text-muted-foreground">
                    {t('home.hero.subtitle')}
                </p>
            </div>

            <div className="max-w-md mx-auto mb-8 relative group animate-in zoom-in-95 duration-700 delay-100">
                <div className="absolute -inset-1 bg-gradient-to-r from-primary to-purple-600 rounded-2xl blur opacity-25 group-hover:opacity-50 transition duration-1000"></div>
                <div className="relative bg-white dark:bg-black rounded-xl shadow-2xl flex items-center p-2 ring-1 ring-black/5">
                    <Input 
                        value={text}
                        onChange={(e) => setText(e.target.value.slice(0, 2))}
                        className="border-0 shadow-none focus-visible:ring-0 text-center text-4xl font-bold font-display h-20 bg-transparent placeholder:text-muted/20"
                        placeholder={t('home.hero.placeholder')}
                        maxLength={2}
                        autoFocus
                        aria-label="Enter favicon text"
                    />
                    <div className="absolute right-6 pointer-events-none text-muted-foreground/30 font-medium text-sm">
                        {text.length}/2
                    </div>
                </div>
            </div>

            <div className="flex flex-col items-center gap-4 mb-12 animate-in slide-in-from-bottom-4 duration-700 delay-150">
                <div className="text-center text-sm text-muted-foreground flex items-center justify-center gap-2 mb-2">
                    <Sparkles className="w-4 h-4" /> {t('home.hero.helper')}
                </div>
                
                <Button 
                    variant="outline" 
                    onClick={shuffleFonts}
                    className="rounded-full px-6 bg-white/50 backdrop-blur-sm border-white/20 shadow-sm hover:shadow-md transition-all active:scale-95"
                >
                    <Shuffle className="w-4 h-4 mr-2" /> {t('home.hero.randomize')}
                </Button>
            </div>

            <div className="flex justify-center mb-12 animate-in slide-in-from-bottom-4 duration-700 delay-200">
                <Tabs value={category} onValueChange={setCategory} className="w-full max-w-3xl">
                    <TabsList className="w-full grid grid-cols-3 md:grid-cols-6 h-auto p-1 bg-muted/50 backdrop-blur-sm">
                        {categories.map(c => (
                            <TabsTrigger key={c} value={c} className="capitalize py-2">
                                {c}
                            </TabsTrigger>
                        ))}
                    </TabsList>
                </Tabs>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-6 mb-20">
                {filteredTemplates.map((template, i) => (
                    <div key={template.id} className="animate-in fade-in slide-in-from-bottom-4" style={{ animationDelay: `${Math.min(i * 30, 500)}ms` }}>
                        <TemplateCard 
                            template={template} 
                            text={text || "A"} 
                            fontFamily={fontMap[template.id]?.family}
                            fontWeight={fontMap[template.id]?.weight}
                        />
                    </div>
                ))}
            </div>
        </main>

        <USPBanner />
        
        <FAQSection items={FAQS} title={t('home.faq.title')} />

        <footer className="text-center text-muted-foreground py-8 border-t border-border/50">
            <div className="flex items-center justify-center gap-4 text-sm">
                <span>{t('common.footer.copyright')}</span>
                <span>•</span>
                <a href="#" className="hover:text-primary transition-colors">{t('common.footer.privacy')}</a>
                <span>•</span>
                <a href="#" className="flex items-center gap-1 hover:text-primary transition-colors">
                    <Github className="w-4 h-4" /> {t('common.footer.opensource')}
                </a>
            </div>
        </footer>

      </div>
    </div>
  );
}
