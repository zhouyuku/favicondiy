import { useState } from "react";
import Header from "@/components/Header";
import bgImage from "@/assets/bg.jpg";
import { Github, Upload, Loader2, Download } from "lucide-react";
import { useImageProcessor } from "@/hooks/useImageProcessor";
import ImageEditor from "@/components/image/ImageEditor";
import PreviewSection from "@/components/image/PreviewSection";
import { downloadImagePackage } from "@/lib/image-exporter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import SEO from "@/components/SEO";
import FAQSection, { generateFAQSchema, type FAQItem } from "@/components/FAQSection";
import USPBanner from "@/components/USPBanner";
import { useTranslation } from "react-i18next";

export default function ImageGenerator() {
  const { t } = useTranslation();
  const [imageSrc, setImageSrc] = useState<string | null>(null);
  const { config, updateConfig, previewUrl, canvasRef } = useImageProcessor(imageSrc);
  const [loading, setLoading] = useState(false);

  const FAQS: FAQItem[] = [
    { question: t('image.faq.q1'), answer: t('image.faq.a1') },
    { question: t('image.faq.q2'), answer: t('image.faq.a2') },
    { question: t('image.faq.q3'), answer: t('image.faq.a3') },
    { question: t('image.faq.q4'), answer: t('image.faq.a4') }
  ];

  const HOW_TO_SCHEMA = {
    "@context": "https://schema.org",
    "@type": "HowTo",
    "name": t('image.howto.title'),
    "step": [
      { "@type": "HowToStep", "name": t('image.howto.s1'), "text": t('image.howto.t1') },
      { "@type": "HowToStep", "name": t('image.howto.s2'), "text": t('image.howto.t2') },
      { "@type": "HowToStep", "name": t('image.howto.s3'), "text": t('image.howto.t3') }
    ]
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        setImageSrc(event.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDownload = async () => {
    if (!canvasRef.current) return;
    setLoading(true);
    try {
        await downloadImagePackage(canvasRef.current);
        toast.success(t('common.success'));
    } catch (e) {
        toast.error(t('common.error'));
    } finally {
        setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background relative font-sans selection:bg-primary/20 pb-20">
      
      <SEO 
        title={t('image.seo.title')}
        description={t('image.seo.description')}
        canonical="/image"
        structuredData={[generateFAQSchema(FAQS), HOW_TO_SCHEMA]}
      />
      
      {/* Background */}
      <div className="fixed inset-0 pointer-events-none z-0 opacity-30">
        <div className="absolute top-0 left-0 w-full h-full bg-cover bg-center" style={{ backgroundImage: `url(${bgImage})` }} />
        <div className="absolute inset-0 bg-white/60 dark:bg-black/60 backdrop-blur-3xl" />
      </div>

      <div className="relative z-10 container mx-auto px-4 py-12 max-w-6xl">
        <Header />

        <main>
            {!imageSrc ? (
                /* Upload State */
                <div className="max-w-2xl mx-auto animate-in zoom-in-95 duration-700">
                    <Card className="bg-white/50 backdrop-blur-md border-2 border-dashed border-primary/20 hover:border-primary/50 transition-colors p-16 text-center cursor-pointer group relative overflow-hidden">
                        <input 
                            type="file" 
                            accept="image/*" 
                            onChange={handleFileUpload}
                            className="absolute inset-0 opacity-0 cursor-pointer z-20"
                            aria-label="Upload image"
                        />
                        <div className="relative z-10 flex flex-col items-center gap-4">
                            <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform duration-500">
                                <Upload className="w-10 h-10 text-primary" />
                            </div>
                            <h2 className="text-3xl font-bold font-display">{t('image.hero.title')}</h2>
                            <p className="text-lg text-muted-foreground max-w-sm whitespace-pre-wrap">
                                {t('image.hero.subtitle')}
                            </p>
                        </div>
                    </Card>
                </div>
            ) : (
                /* Workspace State */
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 animate-in slide-in-from-bottom-8 duration-700">
                    
                    {/* Left: Editor & Main Preview */}
                    <div className="lg:col-span-5 space-y-6">
                        <Card className="p-6 bg-white/80 dark:bg-black/80 backdrop-blur-xl border-white/20 shadow-xl">
                            <div className="aspect-square bg-[url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAAAXNSR0IArs4c6QAAAB5JREFUKFNjYCAdMBLgwf///3+Gkf///4/XQHg4AAAB2B02Y1537gAAAABJRU5ErkJggg==')] rounded-xl overflow-hidden border mb-6 relative flex items-center justify-center">
                                <img src={previewUrl} className="max-w-full max-h-full object-contain shadow-2xl" alt="Favicon Preview" />
                                {/* Hidden Canvas for processing */}
                                <canvas ref={canvasRef} className="hidden" />
                            </div>
                            
                            <ImageEditor config={config} updateConfig={updateConfig} />

                            <div className="pt-6 mt-6 border-t">
                                <Button 
                                    size="lg" 
                                    className="w-full text-lg font-bold shadow-lg shadow-primary/20" 
                                    onClick={handleDownload}
                                    disabled={loading}
                                >
                                    {loading ? <Loader2 className="w-5 h-5 mr-2 animate-spin" /> : <Download className="w-5 h-5 mr-2" />}
                                    {t('image.hero.download_btn')}
                                </Button>
                                <Button 
                                    variant="ghost" 
                                    className="w-full mt-2 text-muted-foreground"
                                    onClick={() => setImageSrc(null)}
                                >
                                    {t('image.hero.upload_btn')}
                                </Button>
                            </div>
                        </Card>
                    </div>

                    {/* Right: Previews */}
                    <div className="lg:col-span-7">
                        <div className="sticky top-8">
                            <h2 className="text-2xl font-bold font-display mb-6">{t('image.preview.title')}</h2>
                            <PreviewSection previewUrl={previewUrl} />
                        </div>
                    </div>

                </div>
            )}
        </main>

        <USPBanner />

        <FAQSection items={FAQS} title={t('image.faq.title')} />

        {/* Footer */}
        <footer className="text-center text-muted-foreground py-8 mt-12 border-t border-border/50">
            <div className="flex items-center justify-center gap-4 text-sm">
                <span>{t('common.footer.copyright')}</span>
                <span>•</span>
                <a href="#" className="hover:text-primary transition-colors">{t('common.footer.privacy')}</a>
                <span>•</span>
                <a href="#" className="flex items-center gap-1 hover:text-primary transition-colors">
                    <Github className="w-4 h-4" /> {t('common.footer.opensource')}
                </a>
            </div>
        </footer>
      </div>
    </div>
  );
}
