import { useState } from 'react';
import EmojiPicker, { type EmojiClickData, EmojiStyle } from 'emoji-picker-react';
import { TEMPLATES } from '@/lib/icon-templates';
import TemplateCard from '@/components/TemplateCard';
import Header from '@/components/Header';
import { Button } from '@/components/ui/button';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Github, Smile, ChevronDown } from 'lucide-react';
import bgImage from '@/assets/bg.jpg';
import SEO from '@/components/SEO';
import FAQSection, { generateFAQSchema, type FAQItem } from '@/components/FAQSection';
import USPBanner from '@/components/USPBanner';
import { useTranslation } from 'react-i18next';

export default function EmojiGenerator() {
  const { t } = useTranslation();
  const [emoji, setEmoji] = useState("😎");
  const [isOpen, setIsOpen] = useState(false);

  const FAQS: FAQItem[] = [
    { question: t('emoji.faq.q1'), answer: t('emoji.faq.a1') },
    { question: t('emoji.faq.q2'), answer: t('emoji.faq.a2') },
    { question: t('emoji.faq.q3'), answer: t('emoji.faq.a3') },
    { question: t('emoji.faq.q4'), answer: t('emoji.faq.a4') }
  ];

  const HOW_TO_SCHEMA = {
    "@context": "https://schema.org",
    "@type": "HowTo",
    "name": t('emoji.howto.title'),
    "step": [
      { "@type": "HowToStep", "name": t('emoji.howto.s1'), "text": t('emoji.howto.t1') },
      { "@type": "HowToStep", "name": t('emoji.howto.s2'), "text": t('emoji.howto.t2') },
      { "@type": "HowToStep", "name": t('emoji.howto.s3'), "text": t('emoji.howto.t3') }
    ]
  };

  const onEmojiClick = (emojiData: EmojiClickData) => {
    setEmoji(emojiData.emoji);
    setIsOpen(false);
  };

  return (
    <div className="min-h-screen bg-background relative font-sans selection:bg-primary/20">
      
      <SEO 
        title={t('emoji.seo.title')}
        description={t('emoji.seo.description')}
        canonical="/emoji"
        structuredData={[generateFAQSchema(FAQS), HOW_TO_SCHEMA]}
      />
      
      <div className="fixed inset-0 pointer-events-none z-0 opacity-30">
        <div className="absolute top-0 left-0 w-full h-full bg-cover bg-center" style={{ backgroundImage: `url(${bgImage})` }} />
        <div className="absolute inset-0 bg-white/60 dark:bg-black/60 backdrop-blur-3xl" />
      </div>

      <div className="relative z-10 container mx-auto px-4 py-12 max-w-6xl">
        
        <Header />

        <main>
            {/* Emoji Selector */}
            <div className="flex flex-col items-center mb-16 animate-in zoom-in-95 duration-700 delay-100">
                 
                 <div className="relative group">
                    <div className="absolute -inset-1 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-3xl blur opacity-25 group-hover:opacity-50 transition duration-1000"></div>
                    
                    <Popover open={isOpen} onOpenChange={setIsOpen}>
                        <PopoverTrigger asChild>
                            <Button 
                                variant="outline" 
                                className="relative h-40 w-40 rounded-3xl border-0 bg-white/80 dark:bg-black/80 backdrop-blur-xl shadow-2xl flex flex-col items-center justify-center gap-2 hover:scale-105 transition-all duration-300"
                                aria-label="Open emoji picker"
                            >
                                <span className="text-7xl leading-none filter drop-shadow-sm">{emoji}</span>
                                <span className="text-xs text-muted-foreground flex items-center gap-1 font-medium bg-muted/50 px-2 py-1 rounded-full mt-2">
                                    {t('emoji.hero.change')} <ChevronDown className="w-3 h-3" />
                                </span>
                            </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-full p-0 border-none shadow-xl bg-transparent" side="bottom" sideOffset={20}>
                            <EmojiPicker 
                                onEmojiClick={onEmojiClick}
                                autoFocusSearch={false}
                                lazyLoadEmojis={true}
                                emojiStyle={EmojiStyle.NATIVE}
                                skinTonesDisabled
                            />
                        </PopoverContent>
                    </Popover>
                 </div>

                 <div className="mt-6 text-center text-sm text-muted-foreground flex items-center gap-2">
                    <Smile className="w-4 h-4" /> {t('emoji.hero.helper')}
                 </div>
            </div>

            {/* Grid */}
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-6 mb-20">
                {TEMPLATES.map((template, i) => (
                    <div key={template.id} className="animate-in fade-in slide-in-from-bottom-4" style={{ animationDelay: `${Math.min(i * 30, 500)}ms` }}>
                        <TemplateCard 
                            template={template} 
                            text={emoji} 
                            fontFamily={'"Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji"'}
                            fontWeight={400}
                        />
                    </div>
                ))}
            </div>
        </main>

        <USPBanner />

        <FAQSection items={FAQS} title={t('emoji.faq.title')} />

        {/* Footer */}
        <footer className="text-center text-muted-foreground py-8 border-t border-border/50">
            <div className="flex items-center justify-center gap-4 text-sm">
                <span>{t('common.footer.copyright')}</span>
                <span>•</span>
                <a href="#" className="hover:text-primary transition-colors">{t('common.footer.privacy')}</a>
                <span>•</span>
                <a href="#" className="flex items-center gap-1 hover:text-primary transition-colors">
                    <Github className="w-4 h-4" /> {t('common.footer.opensource')}
                </a>
            </div>
        </footer>

      </div>
    </div>
  );
}
