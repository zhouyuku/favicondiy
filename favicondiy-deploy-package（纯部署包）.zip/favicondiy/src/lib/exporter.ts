import { renderToStaticMarkup } from 'react-dom/server';
import JSZip from 'jszip';
import { saveAs } from 'file-saver';
import type { IconTemplate } from './icon-templates';
import React from 'react';

export const generateAndDownloadZip = async (template: IconTemplate, text: string, fontFamily?: string, fontWeight?: string | number) => {
  const zip = new JSZip();
  const sizes = [16, 32, 48, 180, 192, 512];
  
  // 1. Render SVG to string
  // We need to instantiate the component with the specific font family
  const svgString = renderToStaticMarkup(
    React.createElement(template.Component, { text, size: 1024, fontFamily, fontWeight })
  );
  
  // 2. Prepare SVG for loading
  // We need to ensure web fonts are available in the context where the image is drawn.
  // Converting SVG string to data URI might lose web font references if they are not embedded.
  // However, for canvas drawing from data URI, external fonts are often blocked or fail to load.
  // A robust solution involves embedding the font as base64 in CSS within the SVG.
  // But that's complex. For now, since we are in the browser, if we use the same loaded fonts, it might work if we are lucky with the browser cache/environment.
  // Actually, standard Canvas `drawImage` with SVG data URI often fails to render external web fonts (security sandbox).
  // Strategy: For this "DIY" tool, we might rely on the fact that if the user has the font loaded, it might work, OR accept that specialized fonts might fallback in the export if we don't inline them.
  // To fix this properly, we should fetch the font file, base64 encode it, and inject a <style> @font-face block into the SVG.
  // Given the constraint, let's try the simple way first. If it fails (fonts look wrong in PNG), we might need the complex inline approach.
  // Update: To ensure it works, let's just keep the simple approach for now as full font inlining is heavy. 
  // Most browser Canvas implementations sanitize external resources in SVG data URIs. 
  
  const svgUrl = `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svgString)}`;
  
  // 3. Helper to create PNG blob
  const createPngBlob = (size: number): Promise<Blob> => {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = size;
        canvas.height = size;
        const ctx = canvas.getContext('2d');
        if (!ctx) return reject('No ctx');
        
        ctx.drawImage(img, 0, 0, size, size);
        canvas.toBlob((blob) => {
          if (blob) resolve(blob);
          else reject('Blob failed');
        }, 'image/png');
      };
      img.onerror = reject;
      img.src = svgUrl;
    });
  };

  try {
    // Generate all sizes
    for (const size of sizes) {
      const blob = await createPngBlob(size);
      if (size === 180) zip.file("apple-touch-icon.png", blob);
      else if (size === 192) zip.file("android-chrome-192x192.png", blob);
      else if (size === 512) zip.file("android-chrome-512x512.png", blob);
      else zip.file(`favicon-${size}x${size}.png`, blob);
      
      // Favicon.ico fallback (using 32x32 PNG renamed)
      if (size === 32) zip.file("favicon.ico", blob);
    }

    // Manifest
    const manifest = {
        name: "My Website",
        short_name: "Web",
        icons: [
            { src: "/android-chrome-192x192.png", sizes: "192x192", type: "image/png" },
            { src: "/android-chrome-512x512.png", sizes: "512x512", type: "image/png" }
        ],
        theme_color: "#ffffff",
        background_color: "#ffffff",
        display: "standalone"
    };
    zip.file("site.webmanifest", JSON.stringify(manifest, null, 2));

    // HTML Snippet
    const html = `
<link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">
<link rel="manifest" href="/site.webmanifest">
    `.trim();
    zip.file("tags.html", html);

    // Download
    const content = await zip.generateAsync({ type: "blob" });
    saveAs(content, `favicon-${template.id}.zip`);

  } catch (error) {
    console.error("Export failed:", error);
    throw error;
  }
};
