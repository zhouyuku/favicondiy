import React from 'react';

export type TemplateProps = {
  text: string;
  size?: number;
  fontFamily?: string;
  fontWeight?: string | number;
};

export interface IconTemplate {
  id: string;
  name: string;
  category: string;
  Component: React.FC<TemplateProps>;
}

export type FontConfig = {
  family: string;
  weight: string;
};

// Expanded Font Library with Weights
export const FONT_CONFIGS: FontConfig[] = [
  { family: "Outfit", weight: "700" }, // Bold Default
  { family: "Outfit", weight: "800" }, // Extra Bold
  { family: "Inter", weight: "600" },
  { family: "Roboto", weight: "700" },
  { family: "Montserrat", weight: "700" },
  { family: "Lato", weight: "300" }, // Light
  { family: "Lato", weight: "900" }, // Black
  { family: "Open Sans", weight: "700" },
  { family: "Playfair Display", weight: "700" }, // Serif
  { family: "Merriweather", weight: "700" }, // Serif
  { family: "Righteous", weight: "400" }, // Display
  { family: "Fredoka", weight: "600" }, // Rounded
  { family: "Bebas Neue", weight: "400" }, // Condensed
  { family: "Space Mono", weight: "700" }, // Mono
  { family: "Raleway", weight: "100" }, // Thin
  { family: "Raleway", weight: "300" }, // Light
  { family: "Raleway", weight: "900" }, // Black
  { family: "Quicksand", weight: "300" }, // Light Rounded
  { family: "Quicksand", weight: "700" }, // Bold Rounded
  { family: "Anton", weight: "400" }, // Tall Bold
  { family: "Archivo Black", weight: "400" }, // Heavy
  { family: "Alfa Slab One", weight: "400" }, // Heavy Slab
  { family: "Passion One", weight: "900" }, // Heavy Display
];

// Helper to get font size based on text length
const getFontSize = (text: string, base: number) => {
  if (text.length === 1) return base;
  if (text.length === 2) return base * 0.8;
  return base * 0.6;
};

// Common text props for visual centering
const TEXT_DY = ".35em";

// --- Templates ---

// New: Transparent (Text Only)
const TransparentText: React.FC<TemplateProps> = ({ text, size = 512, fontFamily = "Outfit", fontWeight = "800" }) => (
  <svg width={size} height={size} viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
    <text x="50%" y="50%" dy={TEXT_DY} textAnchor="middle" fill="#000000" 
          fontFamily={`${fontFamily}, sans-serif`} fontWeight={fontWeight} fontSize={getFontSize(text, 400)}>
      {text}
    </text>
  </svg>
);

// 1. Classic Square (Violet)
const ClassicSquare: React.FC<TemplateProps> = ({ text, size = 512, fontFamily = "Outfit", fontWeight = "700" }) => (
  <svg width={size} height={size} viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
    <rect width="512" height="512" rx="100" fill="#7c3aed" />
    <text x="50%" y="50%" dy={TEXT_DY} textAnchor="middle" fill="white" 
          fontFamily={`${fontFamily}, sans-serif`} fontWeight={fontWeight} fontSize={getFontSize(text, 360)}>
      {text}
    </text>
  </svg>
);

// 2. Classic Circle (Black)
const ClassicCircle: React.FC<TemplateProps> = ({ text, size = 512, fontFamily = "Outfit", fontWeight = "700" }) => (
  <svg width={size} height={size} viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
    <circle cx="256" cy="256" r="256" fill="#18181b" />
    <text x="50%" y="50%" dy={TEXT_DY} textAnchor="middle" fill="white" 
          fontFamily={`${fontFamily}, sans-serif`} fontWeight={fontWeight} fontSize={getFontSize(text, 360)}>
      {text}
    </text>
  </svg>
);

// 3. Modern Gradient (Sunset)
const GradientSunset: React.FC<TemplateProps> = ({ text, size = 512, fontFamily = "Outfit", fontWeight = "700" }) => (
  <svg width={size} height={size} viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <linearGradient id="grad1" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#f43f5e" />
        <stop offset="100%" stopColor="#fbbf24" />
      </linearGradient>
    </defs>
    <rect width="512" height="512" rx="100" fill="url(#grad1)" />
    <text x="50%" y="50%" dy={TEXT_DY} textAnchor="middle" fill="white" 
          fontFamily={`${fontFamily}, sans-serif`} fontWeight={fontWeight} fontSize={getFontSize(text, 360)}>
      {text}
    </text>
  </svg>
);

// 4. Modern Gradient (Ocean)
const GradientOcean: React.FC<TemplateProps> = ({ text, size = 512, fontFamily = "Outfit", fontWeight = "700" }) => (
  <svg width={size} height={size} viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <linearGradient id="grad2" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#0ea5e9" />
        <stop offset="100%" stopColor="#22c55e" />
      </linearGradient>
    </defs>
    <rect width="512" height="512" rx="100" fill="url(#grad2)" />
    <text x="50%" y="50%" dy={TEXT_DY} textAnchor="middle" fill="white" 
          fontFamily={`${fontFamily}, sans-serif`} fontWeight={fontWeight} fontSize={getFontSize(text, 360)}>
      {text}
    </text>
  </svg>
);

// New: Gradient Aurora
const GradientAurora: React.FC<TemplateProps> = ({ text, size = 512, fontFamily = "Outfit", fontWeight = "700" }) => (
  <svg width={size} height={size} viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <linearGradient id="gradAurora" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#6366f1" />
        <stop offset="100%" stopColor="#10b981" />
      </linearGradient>
    </defs>
    <rect width="512" height="512" rx="100" fill="url(#gradAurora)" />
    <text x="50%" y="50%" dy={TEXT_DY} textAnchor="middle" fill="white" 
          fontFamily={`${fontFamily}, sans-serif`} fontWeight={fontWeight} fontSize={getFontSize(text, 360)}>
      {text}
    </text>
  </svg>
);

// New: Gradient Berry
const GradientBerry: React.FC<TemplateProps> = ({ text, size = 512, fontFamily = "Outfit", fontWeight = "700" }) => (
  <svg width={size} height={size} viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <linearGradient id="gradBerry" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#be185d" />
        <stop offset="100%" stopColor="#fb7185" />
      </linearGradient>
    </defs>
    <rect width="512" height="512" rx="100" fill="url(#gradBerry)" />
    <text x="50%" y="50%" dy={TEXT_DY} textAnchor="middle" fill="white" 
          fontFamily={`${fontFamily}, sans-serif`} fontWeight={fontWeight} fontSize={getFontSize(text, 360)}>
      {text}
    </text>
  </svg>
);

// 5. Hexagon (Tech)
const HexagonTech: React.FC<TemplateProps> = ({ text, size = 512, fontFamily = "monospace", fontWeight = "700" }) => (
  <svg width={size} height={size} viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
    <path d="M256 0 L477 128 L477 384 L256 512 L35 384 L35 128 Z" fill="#0f172a" />
    <text x="50%" y="50%" dy={TEXT_DY} textAnchor="middle" fill="#38bdf8" 
          fontFamily={fontFamily} fontWeight={fontWeight} fontSize={getFontSize(text, 340)}>
      {text}
    </text>
  </svg>
);

// 6. Ghost Outline
const GhostOutline: React.FC<TemplateProps> = ({ text, size = 512, fontFamily = "Outfit", fontWeight = "700" }) => (
  <svg width={size} height={size} viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
    <rect width="492" height="492" x="10" y="10" rx="90" fill="none" stroke="#18181b" strokeWidth="20" />
    <text x="50%" y="50%" dy={TEXT_DY} textAnchor="middle" fill="#18181b" 
          fontFamily={`${fontFamily}, sans-serif`} fontWeight={fontWeight} fontSize={getFontSize(text, 360)}>
      {text}
    </text>
  </svg>
);

// 7. Squircle (Playful)
const SquirclePlay: React.FC<TemplateProps> = ({ text, size = 512, fontFamily = "Outfit", fontWeight = "700" }) => (
  <svg width={size} height={size} viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
    <path d="M256,0 C60,0 0,60 0,256 C0,452 60,512 256,512 C452,512 512,452 512,256 C512,60 452,0 256,0 Z" fill="#ec4899" />
     <text x="50%" y="50%" dy={TEXT_DY} textAnchor="middle" fill="white" 
          fontFamily={`${fontFamily}, sans-serif`} fontWeight={fontWeight} fontSize={getFontSize(text, 360)}>
      {text}
    </text>
  </svg>
);

// 8. Shield (Security)
const ShieldSecure: React.FC<TemplateProps> = ({ text, size = 512, fontFamily = "Outfit", fontWeight = "700" }) => (
  <svg width={size} height={size} viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
    <path d="M256 0 L480 80 V240 C480 380 380 480 256 512 C132 480 32 380 32 240 V80 L256 0 Z" fill="#dc2626" />
    <text x="50%" y="50%" dy={TEXT_DY} textAnchor="middle" fill="white" 
          fontFamily={`${fontFamily}, sans-serif`} fontWeight={fontWeight} fontSize={getFontSize(text, 310)}>
      {text}
    </text>
  </svg>
);

// 9. Dots Pattern
const DotsPattern: React.FC<TemplateProps> = ({ text, size = 512, fontFamily = "Outfit", fontWeight = "700" }) => (
  <svg width={size} height={size} viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
    <rect width="512" height="512" rx="100" fill="#4f46e5" />
    <pattern id="dots" x="0" y="0" width="40" height="40" patternUnits="userSpaceOnUse">
      <circle cx="2" cy="2" r="2" fill="white" opacity="0.3"/>
    </pattern>
    <rect width="512" height="512" rx="100" fill="url(#dots)" />
    <text x="50%" y="50%" dy={TEXT_DY} textAnchor="middle" fill="white" 
          fontFamily={`${fontFamily}, sans-serif`} fontWeight={fontWeight} fontSize={getFontSize(text, 360)}>
      {text}
    </text>
  </svg>
);

// 10. Abstract Blob
const AbstractBlob: React.FC<TemplateProps> = ({ text, size = 512, fontFamily = "Outfit", fontWeight = "700" }) => (
  <svg width={size} height={size} viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
    <rect width="512" height="512" fill="transparent" />
    <path d="M450 256C450 363.157 363.157 450 256 450C148.843 450 62 363.157 62 256C62 148.843 148.843 62 256 62C363.157 62 450 148.843 450 256Z" fill="#8b5cf6" />
    <path d="M480 250C480 380 380 480 250 480C120 480 20 380 20 250C20 120 120 20 250 20C380 20 480 120 480 250Z" fill="#8b5cf6" opacity="0.5" transform="rotate(45 256 256)" />
    <text x="50%" y="50%" dy={TEXT_DY} textAnchor="middle" fill="white" 
          fontFamily={`${fontFamily}, sans-serif`} fontWeight={fontWeight} fontSize={getFontSize(text, 340)}>
      {text}
    </text>
  </svg>
);

// 11. Minimal Dark
const MinimalDark: React.FC<TemplateProps> = ({ text, size = 512, fontFamily = "Outfit", fontWeight = "500" }) => (
  <svg width={size} height={size} viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
    <rect width="512" height="512" rx="120" fill="#000000" />
    <text x="50%" y="50%" dy={TEXT_DY} textAnchor="middle" fill="#ffffff" 
          fontFamily={`${fontFamily}, sans-serif`} fontWeight={fontWeight} fontSize={getFontSize(text, 380)}>
      {text}
    </text>
  </svg>
);

// 12. Minimal Light
const MinimalLight: React.FC<TemplateProps> = ({ text, size = 512, fontFamily = "Outfit", fontWeight = "800" }) => (
  <svg width={size} height={size} viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
    <rect width="512" height="512" rx="120" fill="#ffffff" stroke="#e4e4e7" strokeWidth="2" />
    <text x="50%" y="50%" dy={TEXT_DY} textAnchor="middle" fill="#000000" 
          fontFamily={`${fontFamily}, sans-serif`} fontWeight={fontWeight} fontSize={getFontSize(text, 380)}>
      {text}
    </text>
  </svg>
);

// 13. Retro Glitch
const RetroGlitch: React.FC<TemplateProps> = ({ text, size = 512, fontFamily = "monospace", fontWeight = "700" }) => (
  <svg width={size} height={size} viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
    <rect width="512" height="512" fill="#22c55e" />
    <text x="52%" y="52%" dy={TEXT_DY} textAnchor="middle" fill="#000000" opacity="0.3"
          fontFamily={fontFamily} fontWeight={fontWeight} fontSize={getFontSize(text, 360)}>
      {text}
    </text>
    <text x="48%" y="48%" dy={TEXT_DY} textAnchor="middle" fill="#ffffff" opacity="0.3"
          fontFamily={fontFamily} fontWeight={fontWeight} fontSize={getFontSize(text, 360)}>
      {text}
    </text>
    <text x="50%" y="50%" dy={TEXT_DY} textAnchor="middle" fill="#000000" 
          fontFamily={fontFamily} fontWeight={fontWeight} fontSize={getFontSize(text, 360)}>
      {text}
    </text>
  </svg>
);

// 14. Soft Cloud
const SoftCloud: React.FC<TemplateProps> = ({ text, size = 512, fontFamily = "Outfit", fontWeight = "700" }) => (
  <svg width={size} height={size} viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
    <circle cx="256" cy="256" r="256" fill="#bfdbfe" />
    <circle cx="150" cy="150" r="100" fill="#93c5fd" opacity="0.5" />
    <circle cx="362" cy="362" r="120" fill="#60a5fa" opacity="0.5" />
    <text x="50%" y="50%" dy={TEXT_DY} textAnchor="middle" fill="#1e3a8a" 
          fontFamily={`${fontFamily}, sans-serif`} fontWeight={fontWeight} fontSize={getFontSize(text, 360)}>
      {text}
    </text>
  </svg>
);

// 15. Warning Stripe
const WarningStripe: React.FC<TemplateProps> = ({ text, size = 512, fontFamily = "Outfit", fontWeight = "800" }) => (
  <svg width={size} height={size} viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
    <rect width="512" height="512" rx="80" fill="#fbbf24" />
    <path d="M0,0 L512,512" stroke="#d97706" strokeWidth="40" opacity="0.2" />
    <path d="M512,0 L0,512" stroke="#d97706" strokeWidth="40" opacity="0.2" />
    <text x="50%" y="50%" dy={TEXT_DY} textAnchor="middle" fill="#78350f" 
          fontFamily={`${fontFamily}, sans-serif`} fontWeight={fontWeight} fontSize={getFontSize(text, 360)}>
      {text}
    </text>
  </svg>
);

// New: Solid Coral
const SolidCoral: React.FC<TemplateProps> = ({ text, size = 512, fontFamily = "Outfit", fontWeight = "700" }) => (
  <svg width={size} height={size} viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
    <rect width="512" height="512" rx="100" fill="#f43f5e" />
    <text x="50%" y="50%" dy={TEXT_DY} textAnchor="middle" fill="white" 
          fontFamily={`${fontFamily}, sans-serif`} fontWeight={fontWeight} fontSize={getFontSize(text, 360)}>
      {text}
    </text>
  </svg>
);

// New: Solid Teal
const SolidTeal: React.FC<TemplateProps> = ({ text, size = 512, fontFamily = "Outfit", fontWeight = "700" }) => (
  <svg width={size} height={size} viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
    <rect width="512" height="512" rx="100" fill="#0d9488" />
    <text x="50%" y="50%" dy={TEXT_DY} textAnchor="middle" fill="white" 
          fontFamily={`${fontFamily}, sans-serif`} fontWeight={fontWeight} fontSize={getFontSize(text, 360)}>
      {text}
    </text>
  </svg>
);

// New: Neon Cyber
const NeonCyber: React.FC<TemplateProps> = ({ text, size = 512, fontFamily = "monospace", fontWeight = "700" }) => (
  <svg width={size} height={size} viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
    <rect width="500" height="500" x="6" y="6" rx="90" fill="#000000" stroke="#d946ef" strokeWidth="12" />
    <text x="50%" y="50%" dy={TEXT_DY} textAnchor="middle" fill="#d946ef" 
          fontFamily={fontFamily} fontWeight={fontWeight} fontSize={getFontSize(text, 340)}
          style={{ textShadow: "0 0 20px #d946ef" }}>
      {text}
    </text>
  </svg>
);

// New: Neon Tron
const NeonTron: React.FC<TemplateProps> = ({ text, size = 512, fontFamily = "monospace", fontWeight = "700" }) => (
  <svg width={size} height={size} viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
    <rect width="500" height="500" x="6" y="6" rx="90" fill="#0f172a" stroke="#06b6d4" strokeWidth="12" />
    <path d="M60 256 L452 256" stroke="#06b6d4" strokeWidth="4" opacity="0.3" />
    <path d="M256 60 L256 452" stroke="#06b6d4" strokeWidth="4" opacity="0.3" />
    <text x="50%" y="50%" dy={TEXT_DY} textAnchor="middle" fill="#06b6d4" 
          fontFamily={fontFamily} fontWeight={fontWeight} fontSize={getFontSize(text, 340)}
          style={{ textShadow: "0 0 20px #06b6d4" }}>
      {text}
    </text>
  </svg>
);

// New: Brutalism Yellow
const BrutalismYellow: React.FC<TemplateProps> = ({ text, size = 512, fontFamily = "Outfit", fontWeight = "800" }) => (
  <svg width={size} height={size} viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
    <rect x="20" y="20" width="492" height="492" rx="0" fill="#000000" />
    <rect x="0" y="0" width="492" height="492" rx="0" fill="#facc15" stroke="#000000" strokeWidth="12" />
    <text x="48%" y="48%" dy={TEXT_DY} textAnchor="middle" fill="#000000" 
          fontFamily={`${fontFamily}, sans-serif`} fontWeight={fontWeight} fontSize={getFontSize(text, 380)}>
      {text}
    </text>
  </svg>
);

// New: Brutalism Pink
const BrutalismPink: React.FC<TemplateProps> = ({ text, size = 512, fontFamily = "Outfit", fontWeight = "800" }) => (
  <svg width={size} height={size} viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
    <rect x="20" y="20" width="492" height="492" rx="60" fill="#000000" />
    <rect x="0" y="0" width="492" height="492" rx="60" fill="#fb7185" stroke="#000000" strokeWidth="12" />
    <text x="48%" y="48%" dy={TEXT_DY} textAnchor="middle" fill="#000000" 
          fontFamily={`${fontFamily}, sans-serif`} fontWeight={fontWeight} fontSize={getFontSize(text, 380)}>
      {text}
    </text>
  </svg>
);

// New: Bauhaus
const BauhausGeo: React.FC<TemplateProps> = ({ text, size = 512, fontFamily = "Outfit", fontWeight = "700" }) => (
  <svg width={size} height={size} viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
    <rect width="512" height="512" fill="#f1f5f9" />
    <rect x="0" y="0" width="256" height="512" fill="#3b82f6" />
    <circle cx="256" cy="256" r="128" fill="#ef4444" />
    <rect x="256" y="256" width="256" height="256" fill="#facc15" />
    <text x="50%" y="50%" dy={TEXT_DY} textAnchor="middle" fill="#ffffff" 
          fontFamily={`${fontFamily}, sans-serif`} fontWeight={fontWeight} fontSize={getFontSize(text, 360)}
          style={{ textShadow: "2px 2px 0px #000" }}>
      {text}
    </text>
  </svg>
);

// New: Pattern Waves
const PatternWaves: React.FC<TemplateProps> = ({ text, size = 512, fontFamily = "Outfit", fontWeight = "700" }) => (
  <svg width={size} height={size} viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
    <rect width="512" height="512" rx="100" fill="#8b5cf6" />
    <path d="M0 64 Q 128 0 256 64 T 512 64 V 128 Q 384 192 256 128 T 0 128 Z" fill="white" opacity="0.1" />
    <path d="M0 256 Q 128 192 256 256 T 512 256 V 320 Q 384 384 256 320 T 0 320 Z" fill="white" opacity="0.1" />
    <path d="M0 448 Q 128 384 256 448 T 512 448 V 512 Q 384 576 256 512 T 0 512 Z" fill="white" opacity="0.1" />
    <text x="50%" y="50%" dy={TEXT_DY} textAnchor="middle" fill="white" 
          fontFamily={`${fontFamily}, sans-serif`} fontWeight={fontWeight} fontSize={getFontSize(text, 360)}>
      {text}
    </text>
  </svg>
);

// New: Shape Diamond
const ShapeDiamond: React.FC<TemplateProps> = ({ text, size = 512, fontFamily = "Outfit", fontWeight = "700" }) => (
  <svg width={size} height={size} viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
    <rect width="512" height="512" fill="transparent" />
    <rect x="76" y="76" width="360" height="360" rx="40" transform="rotate(45 256 256)" fill="#2563eb" />
    <text x="50%" y="50%" dy={TEXT_DY} textAnchor="middle" fill="white" 
          fontFamily={`${fontFamily}, sans-serif`} fontWeight={fontWeight} fontSize={getFontSize(text, 320)}>
      {text}
    </text>
  </svg>
);

// New: Shape Star
const ShapeStar: React.FC<TemplateProps> = ({ text, size = 512, fontFamily = "Outfit", fontWeight = "700" }) => (
  <svg width={size} height={size} viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
    <polygon points="256,20 316,196 502,196 352,306 409,482 256,372 103,482 160,306 10,196 196,196" fill="#f59e0b" />
    <text x="50%" y="50%" dy=".38em" textAnchor="middle" fill="white" 
          fontFamily={`${fontFamily}, sans-serif`} fontWeight={fontWeight} fontSize={getFontSize(text, 240)}>
      {text}
    </text>
  </svg>
);

// New: Eco Leaf
const EcoLeaf: React.FC<TemplateProps> = ({ text, size = 512, fontFamily = "Outfit", fontWeight = "700" }) => (
  <svg width={size} height={size} viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
     <path d="M256 512 C 114 512 0 398 0 256 C 0 114 114 0 256 0 C 398 0 512 114 512 256 C 512 398 512 512 256 512 Z" fill="#4ade80" />
     <path d="M256 0 C 398 0 512 114 512 256 C 512 114 398 0 256 0 Z" fill="#16a34a" />
    <text x="50%" y="50%" dy={TEXT_DY} textAnchor="middle" fill="white" 
          fontFamily={`${fontFamily}, sans-serif`} fontWeight={fontWeight} fontSize={getFontSize(text, 360)}>
      {text}
    </text>
  </svg>
);

// New: Double Circle
const DoubleCircle: React.FC<TemplateProps> = ({ text, size = 512, fontFamily = "Outfit", fontWeight = "700" }) => (
  <svg width={size} height={size} viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
    <circle cx="256" cy="256" r="256" fill="#c084fc" opacity="0.5" />
    <circle cx="256" cy="256" r="200" fill="#9333ea" />
    <text x="50%" y="50%" dy={TEXT_DY} textAnchor="middle" fill="white" 
          fontFamily={`${fontFamily}, sans-serif`} fontWeight={fontWeight} fontSize={getFontSize(text, 300)}>
      {text}
    </text>
  </svg>
);

export const TEMPLATES: IconTemplate[] = [
  { id: 'transparent-text', name: 'Transparent', category: 'minimal', Component: TransparentText },
  { id: 'minimal-dark', name: 'Minimal Dark', category: 'minimal', Component: MinimalDark },
  { id: 'minimal-light', name: 'Minimal Light', category: 'minimal', Component: MinimalLight },
  { id: 'classic-square', name: 'Violet Square', category: 'solid', Component: ClassicSquare },
  { id: 'classic-circle', name: 'Black Circle', category: 'solid', Component: ClassicCircle },
  { id: 'solid-coral', name: 'Coral', category: 'solid', Component: SolidCoral },
  { id: 'solid-teal', name: 'Teal', category: 'solid', Component: SolidTeal },
  { id: 'gradient-sunset', name: 'Sunset Gradient', category: 'gradient', Component: GradientSunset },
  { id: 'gradient-ocean', name: 'Ocean Gradient', category: 'gradient', Component: GradientOcean },
  { id: 'gradient-aurora', name: 'Aurora', category: 'gradient', Component: GradientAurora },
  { id: 'gradient-berry', name: 'Berry', category: 'gradient', Component: GradientBerry },
  { id: 'neon-cyber', name: 'Cyber Neon', category: 'neon', Component: NeonCyber },
  { id: 'neon-tron', name: 'Tron', category: 'neon', Component: NeonTron },
  { id: 'brutalism-yellow', name: 'Brutal Yellow', category: 'brutalism', Component: BrutalismYellow },
  { id: 'brutalism-pink', name: 'Brutal Pink', category: 'brutalism', Component: BrutalismPink },
  { id: 'hexagon-tech', name: 'Tech Hex', category: 'geometric', Component: HexagonTech },
  { id: 'shape-diamond', name: 'Diamond', category: 'geometric', Component: ShapeDiamond },
  { id: 'shape-star', name: 'Star', category: 'geometric', Component: ShapeStar },
  { id: 'bauhaus-geo', name: 'Bauhaus', category: 'geometric', Component: BauhausGeo },
  { id: 'ghost-outline', name: 'Ghost', category: 'minimal', Component: GhostOutline },
  { id: 'squircle-play', name: 'Playful', category: 'playful', Component: SquirclePlay },
  { id: 'shield-secure', name: 'Secure Shield', category: 'geometric', Component: ShieldSecure },
  { id: 'dots-pattern', name: 'Dots', category: 'pattern', Component: DotsPattern },
  { id: 'pattern-waves', name: 'Waves', category: 'pattern', Component: PatternWaves },
  { id: 'abstract-blob', name: 'Blob', category: 'playful', Component: AbstractBlob },
  { id: 'retro-glitch', name: 'Glitch', category: 'playful', Component: RetroGlitch },
  { id: 'soft-cloud', name: 'Cloud', category: 'geometric', Component: SoftCloud },
  { id: 'eco-leaf', name: 'Eco Leaf', category: 'solid', Component: EcoLeaf },
  { id: 'double-circle', name: 'Double Circle', category: 'geometric', Component: DoubleCircle },
  { id: 'warning-stripe', name: 'Construction', category: 'pattern', Component: WarningStripe },
];
