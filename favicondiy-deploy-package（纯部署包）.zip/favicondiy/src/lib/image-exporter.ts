import JSZip from 'jszip';
import { saveAs } from 'file-saver';

export const downloadImagePackage = async (canvas: HTMLCanvasElement) => {
  const zip = new JSZip();
  const sizes = [16, 32, 48, 180, 192, 512];

  const getBlob = (size: number): Promise<Blob> => {
    return new Promise((resolve) => {
        const tempCanvas = document.createElement("canvas");
        tempCanvas.width = size;
        tempCanvas.height = size;
        const ctx = tempCanvas.getContext("2d");
        if(ctx) {
            // High quality resize
            ctx.imageSmoothingEnabled = true;
            ctx.imageSmoothingQuality = "high";
            ctx.drawImage(canvas, 0, 0, size, size);
            tempCanvas.toBlob((blob) => resolve(blob!), "image/png");
        }
    });
  };

  try {
    for (const size of sizes) {
      const blob = await getBlob(size);
      if (size === 180) zip.file("apple-touch-icon.png", blob);
      else if (size === 192) zip.file("android-chrome-192x192.png", blob);
      else if (size === 512) zip.file("android-chrome-512x512.png", blob);
      else zip.file(`favicon-${size}x${size}.png`, blob);
      
      if (size === 32) zip.file("favicon.ico", blob);
    }

    const manifest = {
        name: "My Website",
        short_name: "Web",
        icons: [
            { src: "/android-chrome-192x192.png", sizes: "192x192", type: "image/png" },
            { src: "/android-chrome-512x512.png", sizes: "512x512", type: "image/png" }
        ],
        theme_color: "#ffffff",
        background_color: "#ffffff",
        display: "standalone"
    };
    zip.file("site.webmanifest", JSON.stringify(manifest, null, 2));

    const html = `
<link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">
<link rel="manifest" href="/site.webmanifest">
    `.trim();
    zip.file("tags.html", html);

    const content = await zip.generateAsync({ type: "blob" });
    saveAs(content, "favicon-package.zip");

  } catch (error) {
    console.error("Export failed:", error);
    throw error;
  }
};
