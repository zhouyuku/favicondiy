import { useState, useRef, useEffect, useCallback } from "react";

export type ImageConfig = {
  scale: number;
  borderRadius: number; // 0-50 (%)
  backgroundColor: string;
  padding: number; // 0-100 (px)
};

export function useImageProcessor(imageSrc: string | null) {
  const [config, setConfig] = useState<ImageConfig>({
    scale: 1,
    borderRadius: 0,
    backgroundColor: "transparent",
    padding: 0,
  });
  
  const [previewUrl, setPreviewUrl] = useState<string>("");
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const updateConfig = (key: keyof ImageConfig, value: any) => {
    setConfig((prev) => ({ ...prev, [key]: value }));
  };

  const draw = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas || !imageSrc) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const img = new Image();
    img.onload = () => {
        const size = 512; // Standard High Res
        canvas.width = size;
        canvas.height = size;

        ctx.clearRect(0, 0, size, size);

        // 1. Draw Background & Clip (Shape)
        ctx.save();
        ctx.beginPath();
        const r = (config.borderRadius / 100) * (size / 2);
        ctx.roundRect(0, 0, size, size, r);
        ctx.clip();

        if (config.backgroundColor !== "transparent") {
            ctx.fillStyle = config.backgroundColor;
            ctx.fill();
        }

        // 2. Draw Image
        // Calculate dimensions
        // Base width is size - padding*2
        // Then scale is applied
        const baseW = size - (config.padding * 2);
        const baseH = (img.height / img.width) * baseW;
        
        const w = baseW * config.scale;
        const h = baseH * config.scale;
        
        const x = (size - w) / 2;
        const y = (size - h) / 2;

        ctx.drawImage(img, x, y, w, h);
        ctx.restore();

        setPreviewUrl(canvas.toDataURL("image/png"));
    };
    img.src = imageSrc;
  }, [imageSrc, config]);

  useEffect(() => {
    draw();
  }, [draw]);

  return { config, updateConfig, previewUrl, canvasRef };
}
